var csvjson = require('csvjson');
var fs = require("fs");
var path = require('path');
var readline = require('readline-sync');

// This is where the user inputs the file's relative path.
let file = readline.question("Enter the relative file path. ");

// This is where the user inputs the date.
let inputDate = readline.question("Enter a date (YYYY-MM-DD) or press enter to continue without one. ")

var data = fs.readFileSync(path.join(__dirname, file), { encoding: 'utf8' });

var options = {
    delimiter: ',', // optional
    quote: '"' // optional
};


// This is the passed in CSV file converted to a JSON object.
let jsonObjFromCSV = csvjson.toObject(data, options);


// This function filters the JSON object so that only the investments that meet the date input are kept.
function filterByDate(json, date = Date.now()) {
    date = new Date(date);

    json = json.filter((investment) => new Date(investment['#INVESTMENT DATE']) <= date);

    return json;
}

// This function calculates the total amount of cash raised.
function findTotalCashRaised(json) {
    let total = 0;

    for (let i = 0; i < json.length; i++) {
        total += Number(json[i]['CASH PAID'])
    }

    return total;
}


// This function calculates the total number of shares so I can then determine the percentage of ownership for a given investor.
function findTotalNumberOfShares(json) {
    let total = 0;

    for (let i = 0; i < json.length; i++) {
        total += Number(json[i]['SHARES PURCHASED'])
    }

    return total;
}


// This function consolidates all of an investors transactions into one total investment.
function generateOwners(json) {
    let owners = [];

    for (let i = 0; i < json.length; i++) {
        let found = false;

        if (owners.length > 0) {
            for (let j = 0; j < owners.length; j++) {
                if (owners[j]['investor'] === json[i]['INVESTOR']) {
                    owners[j]['shares'] += Number(json[i]['SHARES PURCHASED']);
                    owners[j]['cash_paid'] += Number(json[i]['CASH PAID'])
                    owners[j]['ownership'] += Number((json[i]['SHARES PURCHASED'] / findTotalNumberOfShares(json) * 100).toFixed(2))
                    found = true;
                }
            }
        }

        if (!found) {
            let temp = {
                investor: (json[i]['INVESTOR']),
                shares: Number(json[i]['SHARES PURCHASED']),
                cash_paid: Number(json[i]['CASH PAID']),
                ownership: Number((json[i]['SHARES PURCHASED'] / findTotalNumberOfShares(json) * 100).toFixed(2))
            }
            owners.push(temp);
        }

    }

    return owners;
}

// This function generates the actual cap table and formats the date appropriately.
function generateCapTable(json, date) {

    if (!date) {
        date = new Date();
        let year = date.getFullYear();
        let month = date.getMonth() + 1;
        let day = date.getDate();
        date = String(month) + '/' + String(day) + '/' + String(year);
    }

    json = filterByDate(json, date);

    return ({
        date: date,
        cash_raised: findTotalCashRaised(json),
        total_number_of_shares: findTotalNumberOfShares(json),
        ownership: generateOwners(json)
    })
}

// The user's requested cap table is logged onto the console.
console.log(generateCapTable(jsonObjFromCSV, inputDate));