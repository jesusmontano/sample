In order to run the code, you must first navigate to the folder directory within
the terminal.

Once in the correct directory, from within the terminal you must run the following
commands: 'npm install csvjson' and 'npm install readline-sync'.

After that has been done, you simply run the command 'node converter.js' from the 
directory. You will then be asked for the relative file path of the CSV file
you are interested in. 

* Within this folder, there is a file called 'sample.csv' that can be used to 
run the code as an example. When prompted to input the relative file path, you
can type in 'sample.csv'. After that, you will be prompted to enter a date, which
is optional. Once that is done, you will see the cap table generated on the console.

* This code works under the assumptions that the headers for the CSV file are as
follows: '# INVESTMENT DATE', 'SHARES PURCHASED',
'CASH PAID', and 'INVESTOR'.

* It's important to not that the name of the header is '# INVESTMENT DATE' and 
not just 'INVESTMENT DATE'.
